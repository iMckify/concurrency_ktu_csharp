using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;


namespace RoomServer
{
	/// <summary>
	/// Service. Class must be marked public, otherwise ASP.NET core runtime will not find it.
	/// </summary>
	[Route("/service")] [ApiController]
	public class ServiceController : ControllerBase
	{

		/// <summary>
		/// Rule to set maximum foul number for a block and block probability
		/// </summary>
		public static readonly int maxFouls = 3;

		/// <summary>
		/// Service logic. Use a singleton instance, since controller is instance-per-request.
		/// </summary>
		private static readonly ServiceLogic logic = new ServiceLogic();

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		[HttpPost]
		[Route("SendMessage")]
		public void SendMessage([FromBody] Message msg)
		{
			lock( logic )
			{
				logic.SendMessage(msg);
			}
		}

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		[HttpGet]
		[Route("GetMessage")]
		public ActionResult<Message> GetMessage()
		{
			lock (logic)
			{
				return logic.GetMessage();
			}
		}

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		[HttpPost]
		[Route("MarkMessage")]
		public void MarkMessage([FromBody] int id)
		{
			lock (logic)
			{
				logic.MarkMessage(id);
			}
		}

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		[HttpDelete]
		[Route("DeleteMessage")]
		public void DeleteMessage([FromBody] int id)
		{
			lock (logic)
			{
				logic.DeleteMessage(id);
			}
		}

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		[HttpGet]
		[Route("GetSender")]
		public ActionResult<Sender> GetSender([FromBody] int senderID)
		{
			lock (logic)
			{
				return logic.GetSender(senderID);
			}
		}

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		[HttpPost]
		[Route("UpdateSender")]
		public void UpdateSender([FromBody] Sender sender, [FromQuery] bool isFromModerator)
		{
			lock (logic)
			{
				logic.UpdateSender(sender, isFromModerator);
			}
		}
	}
}