﻿using System;

namespace RoomServer {

	/// <summary>
	/// Class for Message calls
	/// </summary>
	public class Message {

		/// <summary>
		/// Message ID
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Message sender's ID
		/// </summary>
		public int SenderID { get; set; }

		/// <summary>
		/// Flag, indicating if message is not censored (Good)
		/// </summary>
		public bool isValid { get; set; }

		/// <summary>
		/// Flag, indicating if message has already been checked
		/// </summary>
		public bool isChecked { get; set; }

		/// <summary>
		/// Message constructor. Both parameters generated in client
		/// </summary>
		/// <param name="senderID">Message sender ID</param>
		/// <param name="isValid">Flag, indicating if Message is Good</param>
		public Message(int senderID, bool isValid) {
			this.ID = new Random().Next(1, 1000000);
			this.SenderID = senderID;
            this.isValid = isValid;
            this.isChecked = false;
        }

		/// <summary>
		/// Method to print Message details
		/// </summary>
		/// <returns>Message object text</returns>
		public override string ToString() {
			return $"{SenderID}: message {ID} is {(isValid ? "Good" : "Bad")}";
		}
	}

	/// <summary>
	/// Class for Sender calls
	/// </summary>
	public class Sender {

		/// <summary>
		/// Sender ID
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Sender fouls number
		/// </summary>
		public int Fouls { get; set; }

		/// <summary>
		/// Probability for the Sender to get blocked. Probability is counted using Fouls number
		/// </summary>
		public double Probability { get; set; }

		/// <summary>
		/// Flag, indicating if Sender is blocked
		/// </summary>
		public bool isBlocked { get; set; }

		/// <summary>
		/// Block duration number
		/// </summary>
		public int Maturity { get; set; }

		/// <summary>
		/// Sender constructor
		/// </summary>
		/// <param name="id">Sender ID</param>
		public Sender(int id) {
			this.ID = id;
			this.Fouls = 0;
			this.Probability = 0.0;
			this.isBlocked = false;
			this.Maturity = 0;
		}

		/// <summary>
		/// Method to print Sender details
		/// </summary>
		/// <returns>Sender object text</returns>
		public override string ToString() {
			return $"ParticipantID={ID}, Fouls={Fouls}, Probability={Probability}%, isBlocked={isBlocked}, Maturity={Maturity}";
		}
	}

	/// <summary>
	/// Service contract.
	/// </summary>
	public interface IService {

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		void SendMessage(Message msg);

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		Message GetMessage();

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		void MarkMessage(int id);

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		void DeleteMessage(int id);

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		Sender GetSender(int senderID);

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		void UpdateSender(Sender sender, bool isFromModerator);
	}
}
