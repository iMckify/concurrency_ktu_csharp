﻿using System;
using System.Threading;

using NLog;
using System.Net.Http;
using ServiceReference;

namespace ParticipantClient {

	/// <summary>
	/// Sender Client. Sends a new message
	/// </summary>
	class SenderClient {

		/// <summary>
		/// Logger for this class.
		/// </summary>
		Logger log = LogManager.GetCurrentClassLogger();
		private readonly Object accessLock = new Object();

		static void Main(string[] args) {
            var self = new SenderClient();
            self.Run();
        }

        /// <summary>
        /// Program body.
        /// </summary>
        private void Run()
        {

            //configure logging
            ConfigureLogging();

            var rnd = new Random();
            int clientID = rnd.Next(1000, 9999);

            //run everythin in a loop to recover from connection errors
            while (true) {
                try {
                    //connect to the server
                    var service = new ServiceClient(new HttpClient());

                    //int clientID = 1000; // hardcode clientid for testing racing conditions
                    Console.Title = "Sender " + clientID;

                    Console.WriteLine(new string('=', 100));
                    Console.WriteLine(new string(' ', 50) + clientID);
                    Console.WriteLine(new string('=', 100));


                    //use service
                    int attempt = 0;
                    while (true) {
                        Console.WriteLine($"Attempt {attempt++}.");
                        Sender sender = null;
                        try {
                            sender = service.GetSender(clientID);
                        }
                        catch (Exception e) {
                            sender = new Sender() {
                                Id = clientID,
                                Fouls = 0,
                                Probability = 0.0,
                                IsBlocked = false,
                                Maturity = 0,
                            };
                        }

                        if (sender.IsBlocked) {
                            if (sender.Maturity > 0) {
                                sender.Maturity--;
                            }
                            if (sender.Maturity == 0) {
                                sender.IsBlocked = false;
                            }
                            log.Warn($"{sender.Maturity} Blocks left.");
                            service.UpdateSender(sender, false);

                            Console.WriteLine("---");
                            Thread.Sleep(2000);
                            continue;
                        }

                        var msg = new Message() {
                            Id = new Random().Next(1, 1000000),
                            SenderID = sender.Id,
                            IsValid = rnd.Next(-100, 100) > 0,
                            IsChecked = false,
                        };

                        service.SendMessage(msg);
                        log.Info($"Sent {(msg.IsValid ? "Good" : "Bad")} message {msg.Id}.");
                        Console.WriteLine("---");
                        Thread.Sleep(2000);
                    }
                }
                catch (Exception e) { 
                    //log whatever exception to console
                    log.Warn(e, "Unhandled exception caught. Will restart main loop.");

                    //prevent console spamming
                    Thread.Sleep(2000);
                }
            }
        }

        /// <summary>
        /// Configures logging subsystem.
        /// </summary>
        private void ConfigureLogging() {
			var config = new NLog.Config.LoggingConfiguration();

			var console =
				new NLog.Targets.ConsoleTarget("console")
				{
					Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
				};
			config.AddTarget(console);
			config.AddRuleForAllLevels(console);

			LogManager.Configuration = config;
		}
	}
}

