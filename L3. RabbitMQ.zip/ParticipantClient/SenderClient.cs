﻿using System;
using System.Threading;
using System.Collections.Generic;

using NLog;
using Service.Client;

namespace SenderClient {

	/// <summary>
	/// Sender Client. Sends a new message
	/// </summary>
	class SenderClient {

		/// <summary>
		/// Logger for this class.
		/// </summary>
		Logger log = LogManager.GetCurrentClassLogger();

		static void Main(string[] args) {
            var self = new SenderClient();
            self.Run();
        }

		/// <summary>
		/// Program body.
		/// </summary>
		private void Run() {
			//configure logging
			ConfigureLogging();

			//run everythin in a loop to recover from connection errors
			while (true) {
				try {

					////connect to the server
					var service = new ServiceClient();
					//string clientID = service.ClientId;
					string clientID = service.GetUUID();

					Console.Title = "Sender " + clientID;

					Console.WriteLine(new string('=', 100));
                    Console.WriteLine(new string(' ', 50) + clientID);
					Console.WriteLine(new string('=', 100));

					//use service
					int attempt = 0;
					while (true) {
						Console.WriteLine($"Attempt {attempt++}.");

						var sender = service.GetSender(clientID);
						if (sender == null) {
							sender = new Sender(clientID);
						} else if (sender.isBlocked) {
							if (sender.Maturity > 0) {
								sender.Maturity--;
							}
							if (sender.Maturity == 0) {
								sender.isBlocked = false;
							}
							log.Warn($"{sender.Maturity} Blocks left.");
							service.UpdateSender(sender, false);

							Console.WriteLine("---");
							Thread.Sleep(2000);
							continue;
						}

						string msgID = service.GetMessageID();
						var msg = new Message(sender.ID, msgID, new Random().Next(-100, 100) > 0);

						service.SendMessage(msg);
						log.Info($"Sent {(msg.isValid ? "Good" : "Bad")} message {msg.ID}.");
						Console.WriteLine("---");
						Thread.Sleep(2000);
					}
				} catch (Exception e) {
					//log whatever exception to console
					log.Warn(e, "Unhandled exception caught. Will restart main loop.");

					//prevent console spamming
					Thread.Sleep(2000);
				}
			}
		}

		/// <summary>
		/// Configures logging subsystem.
		/// </summary>
		private void ConfigureLogging() {
			var config = new NLog.Config.LoggingConfiguration();

			var console =
				new NLog.Targets.ConsoleTarget("console")
				{
					Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
				};
			config.AddTarget(console);
			config.AddRuleForAllLevels(console);

			LogManager.Configuration = config;
		}
	}
}

