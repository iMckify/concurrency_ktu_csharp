using System;
using System.Threading;

using NLog;

namespace RoomServer {
    public class Server {

        /// <summary>
        /// Logger for this class.
        /// </summary>
        Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
		/// Program entry point.
		/// </summary>
		/// <param name="args">Command line arguments.</param>
        public static void Main(string[] args) {
            var self = new Server();
            self.Run();
        }

        /// <summary>
		/// Program body.
		/// </summary>
        private void Run() {
            //configure logging
            ConfigureLogging();

            Console.Title = "Server";
            while (true)
            {
                try {
                    //start service
                    var service = new Service();

                    //indicate server is about to start
                    log.Info("Server is about to start\n");

                    //hang main thread						
					while( true ) {
						Thread.Sleep(1000);
					}
                }
                catch (Exception e) {
                    //log exception
                    log.Error(e, "Unhandled exception caught. Server will now restart.");

                    //prevent console spamming
                    Thread.Sleep(2000);
                }
            }

        }

        /// <summary>
        /// Configure loggin subsystem.
        /// </summary>
        private void ConfigureLogging() {
            var config = new NLog.Config.LoggingConfiguration();

            var console =
                new NLog.Targets.ConsoleTarget("console")
                {
                    Layout = @"${date:format=HH\:mm\:ss}|${level}|${message} ${exception}"
                };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);

            LogManager.Configuration = config;
        }
    }
}
