﻿using System;
using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft.Json;
using NLog;

namespace Service.Client {

    /// <summary>
    /// <para>RPC style wrapper for the service.</para>
    /// <para>Static members are thread safe, instance members are not.</para>
    /// </summary>
    public class ServiceClient : IService {

		/// <summary>
		/// Name of the request exchange.
		/// </summary>
		private static readonly string ExchangeName = "Exchange";

		/// <summary>
		/// Name of the request queue.
		/// </summary>
		private static readonly string ServerQueueName = "ServerQueue";

		/// <summary>
		/// Prefix for the name of the client queue.
		/// </summary>
		private static readonly string ClientQueueNamePrefix = "ClientQueue_";


		/// <summary>
		/// Logger for this class.
		/// </summary>
		private Logger log = LogManager.GetCurrentClassLogger();


		/// <summary>
		/// Service client ID.
		/// </summary>
		public string ClientId { get; }

		/// <summary>
		/// Name of the client queue.
		/// </summary>
		private string ClientQueueName { get; }


		/// <summary>
		/// Connection to RabbitMQ message broker.
		/// </summary>
		private IConnection rmqConn;

		/// <summary>
		/// Communications channel to RabbitMQ message broker.
		/// </summary>
		private IModel rmqChann;

		/// <summary>
		/// Consumer for reading from the client queue.
		/// </summary>
		private QueueingBasicConsumer rmqConsumer;


		/// <summary>
		/// Constructor.
		/// </summary>
		public ServiceClient() {
			//initialize properties
			ClientId = Guid.NewGuid().ToString();
			ClientQueueName = ClientQueueNamePrefix + ClientId;

			//connect to the RabbitMQ message broker
			var rmqConnFact = new ConnectionFactory();
			rmqConn = rmqConnFact.CreateConnection();

			//get channel, configure exchange and queue
			rmqChann = rmqConn.CreateModel();

			rmqChann.ExchangeDeclare(exchange: ExchangeName, type: ExchangeType.Direct);
			rmqChann.QueueDeclare(queue: ClientQueueName, durable: true, exclusive: false, autoDelete: false, arguments: null);
			rmqChann.QueueBind(queue: ClientQueueName, exchange: ExchangeName, routingKey: ClientQueueName, arguments: null);

			//connect to the queue as consumer
			//XXX: see https://www.rabbitmq.com/dotnet-api-guide.html#concurrency for threading issues
			rmqConsumer = new QueueingBasicConsumer(rmqChann);
			rmqChann.BasicConsume(queue: ClientQueueName, autoAck: true, consumer: rmqConsumer);
		}

		/// <summary>
		/// Get unique Sender ID
		/// </summary>
		/// <returns>unique ID</returns>
		public string GetUUID() {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);

			//read response
			while (true) {
				BasicDeliverEventArgs delivery = null;
				if (rmqConsumer.Queue.Dequeue(1000, out delivery)) {
					if (delivery.BasicProperties.CorrelationId == requestProps.CorrelationId) {
						var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));
						if (response.Action == "Result_" + methodName) {
							var result = JsonConvert.DeserializeObject<string>(response.Data);
							return result;
						} else {
							log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
						}
					}
				}
			}
		}

		/// <summary>
		/// Get unique Message ID
		/// </summary>
		/// <returns>unique ID</returns>
		public string GetMessageID() {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);

			//read response
			while (true) {
				BasicDeliverEventArgs delivery = null;
				if (rmqConsumer.Queue.Dequeue(1000, out delivery)) {
					if (delivery.BasicProperties.CorrelationId == requestProps.CorrelationId) {
						var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));
						if (response.Action == "Result_" + methodName) {
							var result = JsonConvert.DeserializeObject<string>(response.Data);
							return result;
						} else {
							log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
						}
					}
				}
			}
		}

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		public void SendMessage(Message msg) {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;

			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName, Data = JsonConvert.SerializeObject(msg) };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);
		}

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		public Message GetMessage() {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);

			//read response
			while (true) {
				BasicDeliverEventArgs delivery = null;
				if (rmqConsumer.Queue.Dequeue(1000, out delivery)) {
					if (delivery.BasicProperties.CorrelationId == requestProps.CorrelationId) {
						var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));
						if (response.Action == "Result_" + methodName) {
							var result = JsonConvert.DeserializeObject<Message>(response.Data);
							return result;
						} else {
							log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
						}
					}
				}
			}
		}

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		public void MarkMessage(string id) {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName, Data = JsonConvert.SerializeObject(id) };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);
		}

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		public void DeleteMessage(string id) {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName, Data = JsonConvert.SerializeObject(id) };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);
		}

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		public Sender GetSender(string senderID) {
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName, Data = JsonConvert.SerializeObject(senderID) };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);

			//read response
			while (true) {
				BasicDeliverEventArgs delivery = null;
				if (rmqConsumer.Queue.Dequeue(1000, out delivery)) {
					if (delivery.BasicProperties.CorrelationId == requestProps.CorrelationId) {
						var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));
						if (response.Action == "Result_" + methodName) {
							var result = JsonConvert.DeserializeObject<Sender>(response.Data);
							return result;
						} else {
							log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
						}
					}
				}
			}
		}

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		public void UpdateSender(Sender sender, bool isFromModerator) { 
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			//send request
			var request = new RPCMessage() { Action = "Call_" + methodName, Data = JsonConvert.SerializeObject(new { sender = sender, isFromModerator = isFromModerator }) };

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();
			requestProps.ReplyTo = ClientQueueName;

			rmqChann.BasicPublish(
				exchange: ExchangeName,
				routingKey: ServerQueueName,
				basicProperties: requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
			);
		}
	}
}
