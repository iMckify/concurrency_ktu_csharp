using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
// using Microsoft.AspNetCore.Hosting;
// using Microsoft.Extensions.Configuration;
// using Microsoft.Extensions.Hosting;
// using Microsoft.Extensions.Logging;

using NLog;

namespace Server
{
	public class Server
	{
		/// <summary>
		/// Logger for this class.
		/// </summary>
		Logger log = LogManager.GetCurrentClassLogger();

		/// <summary>
		/// Configure loggin subsystem.
		/// </summary>
		private void ConfigureLogging()
		{
			var config = new NLog.Config.LoggingConfiguration();

			var console =
				new NLog.Targets.ConsoleTarget("console")
				{
					Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
				};
			config.AddTarget(console);
			config.AddRuleForAllLevels(console);

			LogManager.Configuration = config;
		}

		/// <summary>
		/// Program entry point.
		/// </summary>
		/// <param name="args">Command line arguments.</param>
		public static void Main(string[] args)
		{
			var self = new Server();
			self.Run();
		}

		/// <summary>
		/// Program body.
		/// </summary>
		private void Run() 
		{
			//configure logging
			ConfigureLogging();

			//indicate server is about to start
			log.Info("Server is about to start");

			//start the server
			CreateWebHostBuilder().Build().Run();
		}

		/// <summary>
		/// Creates server host builder.
		/// </summary>
		/// <returns>Server host builder.</returns>
		private IWebHostBuilder CreateWebHostBuilder() 
		{
			var hb = 
				WebHost
					.CreateDefaultBuilder(new String[0])
					.UseKestrel(options => {
						options.Listen(IPAddress.Loopback, 5000);
					})
					.UseStartup<Startup>();
			return hb;
		}
	}
}
