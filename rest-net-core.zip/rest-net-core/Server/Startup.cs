﻿using System;
using System.Collections.Generic;
using System.Linq;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

using NSwag;


namespace Server
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //add and configure MVC services            
			services
				.AddMvc(opts => opts.EnableEndpointRouting = false)
					.SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

			//add service for swagger document generation
            services.AddSwaggerDocument();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
			//add MVC services			
			app.UseMvc();	

			//add swagger services, see http://localhost:5000/swagger/ and http://localhost:5000/swagger/v1/swagger.json
            app.UseOpenApi();
            app.UseSwaggerUi3();
        }
    }
}
