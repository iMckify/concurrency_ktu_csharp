﻿using System;
using System.Threading;
using System.Net.Http;

using NLog;

using ServiceReference;


namespace RoomServer
{
    public class Proxy
    {

        private ServiceClient service = new ServiceClient(new HttpClient());

        Logger log = LogManager.GetCurrentClassLogger();

		/// <summary>
		/// Get unique client id
		/// </summary>
		/// <returns>unique id</returns>
		public string GetUUID()
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");
			return service.GetUUID();
		}

		/// <summary>
		/// Get unique message id
		/// </summary>
		/// <returns>unique id</returns>
		public string GetMessageID()
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");
			return service.GetMessageID();
		}

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		public void SendMessage(Message msg)
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");

			ServiceReference.Message sm = new ServiceReference.Message() { 
				Id = msg.ID,
				IsChecked = msg.isChecked,
				IsValid = msg.isValid,
				SenderID = msg.SenderID
			};

			service.SendMessage(sm);
		}

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		public Message GetMessage()
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");

			ServiceReference.Message sm = service.GetMessage();
			if (sm == null) { return null; }
			Message m = new Message() { 
				ID = sm.Id,
				isChecked = sm.IsChecked,
				isValid = sm.IsValid,
				SenderID = sm.SenderID,
			};
			
			return m;
		}

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		public void MarkMessage(string id)
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");

			service.MarkMessage(id);
		}

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		public void DeleteMessage(string id)
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");

			service.DeleteMessage(id);
		}

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		public Sender GetSender(string senderID)
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");

			ServiceReference.Sender s = service.GetSender(senderID);
			if (s == null) { return null; }
			Sender ss = new Sender() { 
				ID = s.Id,
				isBlocked = s.IsBlocked,
				Maturity = s.Maturity,
				Probability = s.Probability,
				Fouls = s.Fouls,
			};

			return ss;
		}

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		public void UpdateSender(Sender ss, bool isFromModerator)
		{
			string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
			log.Info($"Call to {methodName} method in Main(REST) server");

			ServiceReference.Sender s = new ServiceReference.Sender() {
				Id = ss.ID,
				IsBlocked = ss.isBlocked,
				Maturity = ss.Maturity,
				Probability = ss.Probability,
				Fouls = ss.Fouls,
			};

			service.UpdateSender(s, isFromModerator);
		}
	}
}
