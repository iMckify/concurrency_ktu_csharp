﻿using System;
using System.Threading;
using Microsoft.Extensions.DependencyInjection;

using SimpleRpc.Serialization.Hyperion;
using SimpleRpc.Transports;
using SimpleRpc.Transports.Http.Client;

using NLog;

using RoomServer;
using System.Collections.Generic;
using Castle.Core.Internal;

namespace ModeratorClient {

	/// <summary>
	/// Moderator Client. Checks message history
	/// </summary>
	class ModeratorClient {

		/// <summary>
		/// Logger for this class.
		/// </summary>
		Logger log = LogManager.GetCurrentClassLogger();
		private readonly Object accessLock = new Object();

		// only for paint method
		List<string> clientIDs = new List<string>();

		static void Main(string[] args) {
            var self = new ModeratorClient();
            self.Run();
        }

		/// <summary>
		/// Program body.
		/// </summary>
		private void Run() {

			//configure logging
			ConfigureLogging();

			//run everythin in a loop to recover from connection errors
			while (true) {
				try {

					//connect to the server, get service client proxy
					var sc = new ServiceCollection();
					sc.AddSimpleRpcClient(
							"serviceRPC",
							new HttpClientTransportOptions
							{
								Url = "http://127.0.0.1:5014/simplerpc",
								Serializer = "HyperionMessageSerializer"
							}
						)
						.AddSimpleRpcHyperionSerializer();

					sc.AddSimpleRpcProxy<IService>("serviceRPC");

					var sp = sc.BuildServiceProvider();

					var service = sp.GetService<IService>();

					Console.Title = "ModeratorRPC";
					int attempt = 0;

					//use service
					while (true) {
						Thread.Sleep(1000);
						Console.WriteLine(paint($"Attempt {attempt++}."));
						var msg = service.GetMessage();
						if (msg == null) {
							log.Warn(paint($" Moderator has no messages to check."));
							Console.WriteLine(paint("---"));
							continue;
						} else {  
							if (!clientIDs.Contains(msg.SenderID.ToString())) {
								clientIDs.Add(msg.SenderID.ToString());
							}
							log.Info(paint($"{msg.SenderID}| Checking {msg.ID}."));
						}

						var sender = service.GetSender(msg.SenderID);
						if (!msg.isValid) {
							if (sender == null) {
								log.Error(paint($"{msg.SenderID}| Sender not found. Message {msg.ID}."));
								Console.WriteLine("---");
								continue;
							} else if (!sender.isBlocked) {
								int chance = new Random().Next(0, 100);
								sender.Fouls++;
								sender.Probability = (sender.Fouls * 1.0 / 3) * chance;
								log.Warn(paint($"{sender.ID}| {sender.Probability:0.##}% block chance."));
								if (sender.Probability >= 20) {
									sender.isBlocked = true;
									sender.Maturity = sender.Fouls;
									sender.Fouls = 0;
									sender.Probability = 0.0;
									log.Warn(paint($"{sender.ID}| Blocked for {sender.Maturity} periods."));
								}
								log.Info(paint($"{sender.ID}| Updating  sender {msg.ID}."));
								service.UpdateSender(sender, true);
								log.Info(paint($"{sender.ID}| Marking  message {msg.ID}."));
								service.MarkMessage(msg.ID);
								log.Info(paint($"{sender.ID}| Deleting message {msg.ID}."));
								service.DeleteMessage(msg.ID);
							}
						} else {
							log.Info(paint($"{msg.SenderID}| Good {msg.ID}."));
							log.Info(paint($"{sender.ID}| Marking  message {msg.ID}."));
							service.MarkMessage(msg.ID);
						}
						Console.WriteLine(paint("---"));
						
					}
				}
				catch (Exception e) {

					//log whatever exception to console
					log.Warn(e, "Unhandled exception caught. Will restart main loop.");

					//prevent console spamming
					Thread.Sleep(2000);
				}
			}
		}

		/// <summary>
		/// Configures logging subsystem.
		/// </summary>
		private void ConfigureLogging() {
			var config = new NLog.Config.LoggingConfiguration();

			var console =
				new NLog.Targets.ConsoleTarget("console") {
					Layout = @"${date:format=HH\:mm\:ss}|${level}|${message} ${exception}"
				};
			config.AddTarget(console);
			config.AddRuleForAllLevels(console);

			LogManager.Configuration = config;
		}

		/// <summary>
		/// Sets color for log string. White for first sender, Cyan for second sender. DarkGray if string contains none of first two sender IDs.
		/// </summary>
		/// <param name="logMessage">log string</param>
		/// <returns>log string</returns>
		private string paint(string logMessage)
		{
			if (!clientIDs.IsNullOrEmpty()) {
				if (logMessage.Contains(clientIDs[0])) {
					Console.ForegroundColor = ConsoleColor.White;
				}
				else if (clientIDs.Count == 2 && logMessage.Contains(clientIDs[1])) {
					Console.ForegroundColor = ConsoleColor.Cyan;
				}
				else {
					Console.ForegroundColor = ConsoleColor.DarkGray;
				}
			}
			return logMessage;
		}

	}
}
