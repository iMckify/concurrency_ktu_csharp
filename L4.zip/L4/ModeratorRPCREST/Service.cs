﻿using System;
using RoomServer;
//using ServiceReference;


namespace RoomServer
{

	/// <summary>
	/// Service
	/// </summary>
	public class Service : IService
	{

		private Proxy proxy = new Proxy();

		/// <summary>
		/// Rule to set maximum foul number for a block and block probability
		/// </summary>
		public static readonly int maxFouls = 3;

		/// <summary>
		/// Get unique client id
		/// </summary>
		/// <returns>unique id</returns>
		public string GetUUID()
		{
			lock (proxy)
			{
				return proxy.GetUUID();
			}
		}

		/// <summary>
		/// Get unique message id
		/// </summary>
		/// <returns>unique id</returns>
		public string GetMessageID()
		{
			lock (proxy)
			{
				return proxy.GetMessageID();
			}
		}

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		public void SendMessage(Message msg)
		{
			lock (proxy)
			{
				proxy.SendMessage(msg);
			}
		}

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		public Message GetMessage()
		{
			lock (proxy)
			{
				return proxy.GetMessage();
			}
		}

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		public void MarkMessage(string id)
		{
			lock (proxy)
			{
				proxy.MarkMessage(id);
			}
		}

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		public void DeleteMessage(string id)
		{
			lock (proxy)
			{
				proxy.DeleteMessage(id);
			}
		}

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		public Sender GetSender(string senderID)
		{
			lock (proxy)
			{
				return proxy.GetSender(senderID);
			}
		}

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		public void UpdateSender(Sender sender, bool isFromModerator)
		{
			lock (proxy)
			{
				proxy.UpdateSender(sender, isFromModerator);
			}
		}

	}
}