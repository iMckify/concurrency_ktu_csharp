﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace RoomServer {

	/// <summary>
	/// Class for Message calls
	/// </summary>
	[DataContract]
	public class Message {

		/// <summary>
		/// Message ID
		/// </summary>
		[DataMember]
		public string ID { get; set; }

		/// <summary>
		/// Message sender's ID
		/// </summary>
		[DataMember] 
		public string SenderID { get; set; }

		/// <summary>
		/// Flag, indicating if message is not censored (Good)
		/// </summary>
		[DataMember] 
		public bool isValid { get; set; }

		/// <summary>
		/// Flag, indicating if message has already been checked
		/// </summary>
		[DataMember] 
		public bool isChecked { get; set; }

		/// <summary>
		/// Message constructor. Both parameters generated in client
		/// </summary>
		/// <param name="senderID">Message sender ID</param>
		/// <param name="isValid">Flag, indicating if Message is Good</param>
		public Message(string senderID, string messageID, bool isValid) {
			this.ID = messageID;
			this.SenderID = senderID;
            this.isValid = isValid;
            this.isChecked = false;
        }

		public Message() { }

		/// <summary>
		/// Method to print Message details
		/// </summary>
		/// <returns>Message object text</returns>
		public override string ToString() {
			return $"{SenderID}: message {ID} is {(isValid ? "Good" : "Bad")}";
		}
	}

	/// <summary>
	/// Class for Sender calls
	/// </summary>
	[DataContract]
	public class Sender {

		/// <summary>
		/// Sender ID
		/// </summary>
		[DataMember]
		public string ID { get; set; }

		/// <summary>
		/// Sender fouls number
		/// </summary>
		[DataMember]
		public int Fouls { get; set; }

		/// <summary>
		/// Probability for the Sender to get blocked. Probability is counted using Fouls number
		/// </summary>
		[DataMember]
		public double Probability { get; set; }

		/// <summary>
		/// Flag, indicating if Sender is blocked
		/// </summary>
		[DataMember]
		public bool isBlocked { get; set; }

		/// <summary>
		/// Block duration number
		/// </summary>
		[DataMember]
		public int Maturity { get; set; }

		/// <summary>
		/// Sender constructor
		/// </summary>
		/// <param name="id">Sender ID</param>
		public Sender(string id) {
			this.ID = id;
			this.Fouls = 0;
			this.Probability = 0.0;
			this.isBlocked = false;
			this.Maturity = 0;
		}

		public Sender() { }

		/// <summary>
		/// Method to print Sender details
		/// </summary>
		/// <returns>Sender object text</returns>
		public override string ToString() {
			return $"ParticipantID={ID}, Fouls={Fouls}, Probability={Probability}%, isBlocked={isBlocked}, Maturity={Maturity}";
		}
	}

	/// <summary>
	/// Service contract.
	/// </summary>
	[ServiceContract]
	public interface IService {

		/// <summary>
		/// Get unique client id
		/// </summary>
		/// <returns>unique id</returns>
		[OperationContract]
		string GetUUID();

		/// <summary>
		/// Get unique message id
		/// </summary>
		/// <returns>unique id</returns>
		[OperationContract] 
		string GetMessageID();

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		[OperationContract]
		void SendMessage(Message msg);

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		[OperationContract]
		Message GetMessage();

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		[OperationContract]
		void MarkMessage(string id);

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		[OperationContract]
		void DeleteMessage(string id);

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		[OperationContract] 
		Sender GetSender(string senderID);

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		[OperationContract] 
		void UpdateSender(Sender sender, bool isFromModerator);
	}
}
