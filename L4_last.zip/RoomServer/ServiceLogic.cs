using System;
using System.Collections.Generic;
using Castle.Core.Internal;
using NLog;

namespace RoomServer {

	/// <summary>
	/// Service logic
	/// </summary>
	class ServiceLogic : IService {

		/// <summary>
		/// Logger for this class
		/// </summary>
		private Logger log = LogManager.GetCurrentClassLogger();

		/// <summary>
		/// List of Participants (Message senders)
		/// </summary>
		List<Sender> senders = new List<Sender>();

		/// <summary>
		/// Message history
		/// </summary>
		List<Message> messages = new List<Message>();

		/// <summary>
		/// Get unique client id
		/// </summary>
		/// <returns>unique id</returns>
		public string GetUUID() {
			var id = Guid.NewGuid().ToString();
			log.Info(paint($"UUID {id}."));
			return id;
		}

		/// <summary>
		/// Get unique message id
		/// </summary>
		/// <returns>unique id</returns>
		public string GetMessageID() {
			var id = Guid.NewGuid().ToString();
			log.Info(paint($"GetMessageID({id})."));
			return id;
		}

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		public void SendMessage(Message msg) {
			var sender = senders.Find(s => s.ID == msg.SenderID);
			if (sender == null) {
				senders.Add(new Sender(msg.SenderID));
			} else if (sender.isBlocked) { // Pastaba 2. Kad nelenktyniautu Moderatorius ir Siuntejas. Moderatorius uzblokuotu, o Siuntejas vis dar prasiustu viena zinute
				return;
			}
			messages.Add(msg);
			log.Info(paint($"{msg.SenderID}| Send({msg.ID})."));
		}

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		public Message GetMessage() {
			if (!messages.IsNullOrEmpty()) {
				int msgID = messages.FindIndex(m => !m.isChecked);
				if (msgID == -1) {
					log.Warn(paint(" Get() No new messages."));
					return null;
                }

				var msg = messages[msgID];
                log.Info(paint(($"{msg.SenderID}| Get({msg.ID}) {(msg.isValid ? "Good" : "Bad")}.")));

                return msg;
			} else {
				log.Warn(paint(" Get() No new messages."));
				return null;
			}
        }

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		public void MarkMessage(string id) {
			int i = messages.FindIndex(m => m.ID == id);
			if (i == -1) {
				log.Error(paint($" MarkMessage({id}) Not found in List."));
				return;
			}
			Message msg = messages[i];
			msg.isChecked = true;
			log.Info(paint($"{msg.SenderID}| Mark({id})."));
		}

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		public void DeleteMessage(string id) {
			int i = messages.FindIndex(m => m.ID == id);
			if (i == -1) {
				log.Error(paint($" DeleteMessage({id}) Not found in List."));
				return;
			} else {
				Message msg = messages[i];
				messages.RemoveAt(i);
				log.Info(paint($"{msg.SenderID}| Delete({msg.ID})."));
			}
		}

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		public Sender GetSender(string senderID) {
			Sender sender = senders.Find(s => s.ID == senderID);
			if (sender != null) {
				log.Info(paint($"{sender.ID}| GetSender() {(sender.isBlocked ? "Blocked for " + sender.Maturity + " periods" : "Allowed")}."));
			} 
			//else {
			//	log.Error($"{senderID}| GetSender() not found in List.");
			//}
			return sender;
		}

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		public void UpdateSender(Sender sender, bool isFromModerator) {
			int i = senders.FindIndex(p => p.ID == sender.ID);
			if (i == -1) {
				log.Error(paint($"{sender.ID}| UpdatedSender() : not found in List."));
				return;
			}
			if(isFromModerator) {// Pastaba 1. kad moderatorius negaletu atblokuoti lenktyniavimo atveju. Atblokuoja tik SenderClient
				if (senders[i].isBlocked) {
					return;
				}
			}
			senders[i] = sender;
			log.Info(paint($"{sender.ID}| UpdatedSender() {(sender.isBlocked ? "" + sender.Maturity + " Blocks left" : "Allowed")}."));
		}

		/// <summary>
		/// Sets color for log string. White for first sender, Cyan for second sender. DarkGray if string contains none of first two sender IDs.
		/// </summary>
		/// <param name="logMessage">log string</param>
		/// <returns>log string</returns>
		private string paint(string logMessage) {
			if (!senders.IsNullOrEmpty()) {
				if (logMessage.Contains(senders[0].ID.ToString())) { 
					Console.ForegroundColor = ConsoleColor.White;
				} else if (senders.Count == 2 && logMessage.Contains(senders[1].ID.ToString()) ) {
					Console.ForegroundColor = ConsoleColor.Cyan;
				} else {
					Console.ForegroundColor = ConsoleColor.DarkGray;
				}
			}
			return logMessage;
		}
	}
}