using System;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using System.Threading;

using NLog;
using System.Net;

namespace RoomServer {
    public class Server {

        /// <summary>
        /// Logger for this class.
        /// </summary>
        Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
		/// Program entry point.
		/// </summary>
		/// <param name="args">Command line arguments.</param>
        public static void Main(string[] args) {
            var self = new Server();
            self.Run();
        }

        /// <summary>
		/// Program body.
		/// </summary>
        private void Run()
        {
            //configure logging
            ConfigureLogging();

            Console.Title = "Server";
            //indicate server is about to start
            log.Info("Server is about to start\n");

            //start the server
            CreateWebHostBuilder().Build().RunAsync();

            //Console.WriteLine("Holding main thread.");
            while (true)
            {
                Thread.Sleep(1000);
            }
        }

        /// <summary>
        /// Creates server host builder.
        /// </summary>
        /// <returns>Server host builder.</returns>
        private IWebHostBuilder CreateWebHostBuilder()
        {
            var hb =
                WebHost
                    .CreateDefaultBuilder(new String[0])
                    .UseKestrel(options => {
                        options.Listen(IPAddress.Loopback, 5000); // startup warning
                    })
                    .UseSetting(WebHostDefaults.SuppressStatusMessagesKey, "True") // suppress startup messages
                    .UseStartup<Startup>();
            return hb;
        }

        /// <summary>
        /// Configure loggin subsystem.
        /// </summary>
        private void ConfigureLogging() {
            var config = new NLog.Config.LoggingConfiguration();

            var console =
                new NLog.Targets.ConsoleTarget("console")
                {
                    Layout = @"${date:format=HH\:mm\:ss}|${level}|${message} ${exception}"
                };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);

            LogManager.Configuration = config;
        }
    }
}
