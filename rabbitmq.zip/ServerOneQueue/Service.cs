using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using NLog;
using Newtonsoft.Json;

using Common.MQ;


namespace Server 
{
	/// <summary>
	/// Service
	/// </summary>
	class Service
	{
		/// <summary>
		/// Name of the exchange.
		/// </summary>
		private static readonly String ExchangeName = "T120B180.OneQueue.Exchange";

		/// <summary>
		/// Name of the server queue.
		/// </summary>
		private static readonly String QueueName = "T120B180.OneQueue.ServerQueue";
		

		/// <summary>
		/// Logger for this class.
		/// </summary>
		private Logger log = LogManager.GetCurrentClassLogger();


		/// <summary>
		/// Connection to RabbitMQ message broker.
		/// </summary>
		private IConnection rmqConn;

		/// <summary>
		/// Communications channel to RabbitMQ message broker.
		/// </summary>
		private IModel rmqChann;

		/// <summary>
		/// Service logic.
		/// </summary>
		private ServiceLogic logic = new ServiceLogic();


		/// <summary>
		/// Constructor.
		/// </summary>
		public Service() 
		{
			//connect to the RabbitMQ message broker
			var rmqConnFact = new ConnectionFactory();	
			rmqConn = rmqConnFact.CreateConnection();

			//get channel, configure exchange and queue
			rmqChann = rmqConn.CreateModel();
			
			rmqChann.ExchangeDeclare(exchange: ExchangeName, type: ExchangeType.Fanout);
			rmqChann.QueueDeclare(queue: QueueName, durable: true, exclusive: false, autoDelete: false, arguments: null);
			rmqChann.QueueBind(queue: QueueName, exchange: ExchangeName, routingKey: "", arguments: null);

			//connect to the queue as consumer
			//XXX: see https://www.rabbitmq.com/dotnet-api-guide.html#concurrency for threading issues
			var rmqConsumer = new EventingBasicConsumer(rmqChann);
			rmqConsumer.Received += (consumer, delivery) => OnMessageReceived(((EventingBasicConsumer)consumer).Model, delivery);
			rmqChann.BasicConsume(queue: QueueName, autoAck: true, consumer : rmqConsumer);
		}

		/// <summary>
		/// Is invoked to process messages received.
		/// </summary>
		/// <param name="channel">Related communications channel.</param>
		/// <param name="delivery">Message deliver data.</param>
		private void OnMessageReceived(IModel channel, BasicDeliverEventArgs delivery)
		{
			try 
			{
				//get RPC call request
				var request = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));

				//prepare common reply properties
				var replyProps = channel.CreateBasicProperties();
				replyProps.CorrelationId = delivery.BasicProperties.CorrelationId;
				
				//make the call and send response
				switch( request.Action )
				{
					case "Call_AddLiteral":
					{
						//get call arguments
						var args = JsonConvert.DeserializeAnonymousType(request.Data, new {Left = 0, Right = 0});

						//make the call
						var result = 0;
						lock( logic )
						{
							result = logic.AddLiteral(args.Left, args.Right);
						}

						//send response
						var response = 
							new RPCMessage() {
								Action = "Result_AddLiteral",
								Data = JsonConvert.SerializeObject(new {Result = result})
							};

						channel.BasicPublish(
							exchange : ExchangeName, 
							routingKey : "", 
							basicProperties : replyProps,
							body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(response)) 
						);

						//
						break;
					}

					case "Call_AddStruct":
					{
						//get call arguments
						var args = JsonConvert.DeserializeObject<ByValStruct>(request.Data);

						//make the call
						ByValStruct result = null;
						lock( logic )
						{
							result = logic.AddStruct(args);
						}

						//send response
						var response = 
							new RPCMessage() {
								Action = "Result_AddStruct",
								Data = JsonConvert.SerializeObject(result)
							};
							
						channel.BasicPublish(
							exchange : ExchangeName, 
							routingKey : "", 
							basicProperties : replyProps,
							body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(response)) 
						);

						//
						break;
					}

					default: 
					{
						log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
						break;
					}
				}
			}
			catch( Exception e )
			{
				log.Error(e, "Unhandled exception caught when processing a message. The message is now lost.");				
			}			
		}
	}
}