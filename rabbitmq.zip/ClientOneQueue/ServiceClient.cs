using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft.Json;
using NLog;

using Common.MQ;


namespace Client.Service 
{
	/// <summary>
	/// <para>RPC style wrapper for the service.</para>
	/// <para>Static members are thread safe, instance members are not.</para>
	/// </summary>
	class ServiceClient : IService
	{
		/// <summary>
		/// Name of the exchange.
		/// </summary>
		private static readonly String ExchangeName = "T120B180.OneQueue.Exchange";

		/// <summary>
		/// Prefix for the name of the client queue.
		/// </summary>
		private static readonly String QueueNamePrefix = "T120B180.OneQueue.ClientQueue_";


		/// <summary>
		/// Logger for this class.
		/// </summary>
		private Logger log = LogManager.GetCurrentClassLogger();


		/// <summary>
		/// Service client ID.
		/// </summary>
		/// <value></value>
		public String ClientId {get;}

		/// <summary>
		/// Name of the client queue.
		/// </summary>
		private String QueueName {get;}


		/// <summary>
		/// Connection to RabbitMQ message broker.
		/// </summary>
		private IConnection rmqConn;

		/// <summary>
		/// Communications channel to RabbitMQ message broker.
		/// </summary>
		private IModel rmqChann;

		/// <summary>
		/// Consumer for reading from the client queue.
		/// </summary>
		private QueueingBasicConsumer rmqConsumer;


		/// <summary>
		/// Constructor.
		/// </summary>
		public ServiceClient() 
		{
			//initialize properties
			ClientId = Guid.NewGuid().ToString();
			QueueName = QueueNamePrefix + ClientId;

			//connect to the RabbitMQ message broker
			var rmqConnFact = new ConnectionFactory();
			rmqConn = rmqConnFact.CreateConnection();

			//get channel, configure exchange and queue
			rmqChann = rmqConn.CreateModel();
			
			rmqChann.ExchangeDeclare(exchange: ExchangeName, type: ExchangeType.Fanout);
			rmqChann.QueueDeclare(queue: QueueName, durable: true, exclusive: false, autoDelete: false, arguments: null);
			rmqChann.QueueBind(queue: QueueName, exchange: ExchangeName, routingKey: "", arguments: null);

			//connect to the queue as consumer
			//XXX: see https://www.rabbitmq.com/dotnet-api-guide.html#concurrency for threading issues
			rmqConsumer = new QueueingBasicConsumer(rmqChann);
			rmqChann.BasicConsume(queue: QueueName, autoAck: true, consumer : rmqConsumer);
		}

		/// <summary>
		/// Add given numbers.
		/// </summary>
		/// <param name="left">Left number.</param>
		/// <param name="right">Right number.</param>
		/// <returns>left + right</returns>
		public int AddLiteral(int left, int right) 
		{
			//send request
			var request = 
				new RPCMessage()
				{
					Action = "Call_AddLiteral",
					Data = JsonConvert.SerializeObject(new {Left = left, Right = right})
				};

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();

			rmqChann.BasicPublish(
				exchange : ExchangeName, 
				routingKey : "", 
				basicProperties : requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request)) 
			);

			//read response
			while( true )
			{
				BasicDeliverEventArgs delivery = null;
				if( rmqConsumer.Queue.Dequeue(1000, out delivery) ) 
				{
					if( delivery.BasicProperties.CorrelationId == requestProps.CorrelationId )
					{
						var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));
						if( response.Action == "Result_AddLiteral" )
						{
							var result = JsonConvert.DeserializeAnonymousType(response.Data, new {Result = 0}).Result;
							return result;
						}
						else
						{
							log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");							
						}
					}
				}
			}
		}

		/// <summary>
		/// Add given numbers.
		/// </summary>
		/// <param name="leftAndRight">Numbers to add.</param>
		/// <returns>Left + Right in Sum</returns>
		public ByValStruct AddStruct(ByValStruct leftAndRight)
		{
			//send request
			var request = 
				new RPCMessage()
				{
					Action = "Call_AddStruct",
					Data = JsonConvert.SerializeObject(leftAndRight)
				};

			var requestProps = rmqChann.CreateBasicProperties();
			requestProps.CorrelationId = Guid.NewGuid().ToString();

			rmqChann.BasicPublish(
				exchange : ExchangeName, 
				routingKey : "", 
				basicProperties : requestProps,
				body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request)) 
			);

			//read response
			while( true )
			{
				BasicDeliverEventArgs delivery = null;
				if( rmqConsumer.Queue.Dequeue(1000, out delivery) ) 
				{
					if( delivery.BasicProperties.CorrelationId == requestProps.CorrelationId )
					{
						var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body));
						if( response.Action == "Result_AddStruct" )
						{
							var result = JsonConvert.DeserializeObject<ByValStruct>(response.Data);
							return result;
						}
						else
						{
							log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
						}
					}					
				}
			}
		}
	}
}