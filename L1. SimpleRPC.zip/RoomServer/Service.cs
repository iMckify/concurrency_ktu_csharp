using System;

namespace RoomServer {

	/// <summary>
	/// Service
	/// </summary>
	public class Service : IService {

		/// <summary>
		/// Rule to set maximum foul number for a block and block probability
		/// </summary>
		public static readonly int maxFouls = 3;

		/// <summary>
		/// Access lock.
		/// </summary>
		private readonly Object accessLock = new Object();

		/// <summary>
		/// Service logic implementation.
		/// </summary>
		private ServiceLogic logic = new ServiceLogic();

		/// <summary>
		/// Sends a new Message
		/// </summary>
		/// <param name="msg">a Message to be sent</param>
		public void SendMessage(Message msg) {
			lock( accessLock ) {
				logic.SendMessage(msg);
			}
		}

		/// <summary>
		/// Get new unchecked Message
		/// </summary>
		/// <returns>Message or null if all messages are checked</returns>
		public Message GetMessage() {
			lock( accessLock ) {
				return logic.GetMessage();
            }
        }

		/// <summary>
		/// Mark Message as checked
		/// </summary>
		/// <param name="id">Message ID</param>
		public void MarkMessage(int id) { 
			lock( accessLock ) {
				logic.MarkMessage(id);
			}
		}

		/// <summary>
		/// Delete Message
		/// </summary>
		/// <param name="id">ID for a Message to be deleted</param>
		public void DeleteMessage(int id) { 
			lock ( accessLock ) {
				logic.DeleteMessage(id);
			}
		}

		/// <summary>
		/// Get sender
		/// </summary>
		/// <param name="senderID">sender ID</param>
		/// <returns>sender or null if sender is not found</returns>
		public Sender GetSender(int senderID) { 
			lock ( accessLock ) {
				return logic.GetSender(senderID);
			}
		}

		/// <summary>
		/// Update Sender
		/// </summary>
		/// <param name="sender">New Sender</param>
		/// <param name="isFromModerator">flag indicating, if method is used by Moderator client type</param>
		public void UpdateSender(Sender sender, bool isFromModerator) { 
			lock( accessLock ) {
				logic.UpdateSender(sender, isFromModerator);
			}
		}

	}
}